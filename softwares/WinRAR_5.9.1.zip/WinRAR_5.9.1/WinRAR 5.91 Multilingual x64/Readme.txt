  1. Install WinRAR v5.01.
     2. Use this keygen to make a valid keyfile for your name.
     3. Have fun ;)
     
     This keygen generates its keyfile in the user's profile "application 
     data" folder to be run without administrative rights.=================

